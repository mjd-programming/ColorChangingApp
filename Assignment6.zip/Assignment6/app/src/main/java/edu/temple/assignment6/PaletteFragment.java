package edu.temple.assignment6;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import edu.temple.assignment6.dummy.DummyContent;

/**
 * A fragment representing a list of Items.
 */
public class PaletteFragment extends Fragment {

    // TODO: Customize parameter argument names
    private static final String ARG_COLUMN_COUNT = "column-count";
    private static final String ARG_COLORS = "colors";

    // TODO: Customize parameters
    private int mColumnCount = 1;
    private String[] mColors;
    private FragmentListener listener;

    /**
     * Mandatory empty constructor for the fragment manager to instantiate the
     * fragment (e.g. upon screen orientation changes).
     */
    public PaletteFragment() {

    }

    // TODO: Customize parameter initialization
    @SuppressWarnings("unused")
    public static PaletteFragment newInstance(int columnCount, String[] colors) {
        PaletteFragment fragment = new PaletteFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_COLUMN_COUNT, columnCount);
        args.putStringArray(ARG_COLORS, colors);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT);
            mColors = getArguments().getStringArray(ARG_COLORS);
        }
    }

    public interface FragmentListener {
        void onInputSent(int p);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_palette, container, false);
        ListView lv = v.findViewById(R.id.list_view);
        lv.setAdapter(new ColorAdapter(getActivity(), mColors));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                listener.onInputSent(i);
            }
        });
        return v;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof FragmentListener) {
            listener = (FragmentListener) context;
        } else {
            try {
                throw new Exception("Error");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

class ColorAdapter extends BaseAdapter {

    private Context context;
    private String[] colors;

    public ColorAdapter(Context context, String[] colors) {
        super();
        this.context = context;
        this.colors = colors;
    }

    @Override
    public int getCount() {
        return colors.length;
    }

    @Override
    public Object getItem(int i) {
        return colors[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        String current_color = colors[i];
        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
        View v = inflater.inflate(R.layout.palette_item, viewGroup, false);
        TextView color_name = v.findViewById(R.id.list_text);
        color_name.setText(current_color);
        v.setBackgroundColor(Color.parseColor(current_color));
        return v;
    }
}