package edu.temple.assignment6;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity implements PaletteFragment.FragmentListener {

    PaletteFragment paletteFragment;
    CanvasFragment canvasFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        paletteFragment = PaletteFragment.newInstance(1, getResources().getStringArray(R.array.colors));
        canvasFragment = new CanvasFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.container_2, paletteFragment).commit();
        getSupportFragmentManager().beginTransaction().add(R.id.container_1, canvasFragment).commit();
    }

    @Override
    public void onInputSent(int p) {
        canvasFragment.changeBG(getResources().getStringArray(R.array.colors)[p]);
    }
}